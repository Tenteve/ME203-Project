function data=get_words(hero)
% data=GETWORDS(hero)
% This function gets the words from a .txt file and stores them as an array
FID =____ % Open the file
data = ____%scan through the file for each word;
_____ %close the file
end