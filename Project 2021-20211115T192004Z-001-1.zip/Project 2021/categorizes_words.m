function [barx,count]=categorizes_words(dataclean)
c = _______(dataclean);
barx=_______(c)';
count=_______(c);
end