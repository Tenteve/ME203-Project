function [data_filtered,L] = clean_words (data)
% Removes the top most comon words form a cell aray
% https://www.espressoenglish.net/the-100-most-common-words-in-english/
________ % removes the most comon word

data_filtered=data;
L=______;% length of filtered data array
end

