function Output=remove_delim(data)
%Output=remove_delimiters(data)
% Removes [".",",","?","!"] and lower cases data
% Iterates over each string in data
data=data{1};
for i=1:length(____)
    data(i)=_____ %Removes "." from every string
    data(i)=_____ %Removes "," from every string
    data(i)=_____ %Removes "?" from every string
    data(i)=_____ %Removes "!" from every string
    data(i)=_____ %lowercases every string
end
Output=data;
end